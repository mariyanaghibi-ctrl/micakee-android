package com.micakee.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.LocalLayoutDirection
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

private val Teal = Color(0xFF287A68)       // برند سبز می‌کیک
private val DeepTeal = Color(0xFF174F45)   // سبز تیره
private val Gold = Color(0xFFD7AE58)       // طلایی
private val GoldSoft = Color(0xFFF4EBD7)  // کرم طلایی
private val Cream = Color(0xFFFFFAF1)     // پس‌زمینه گرم
private val White = Color(0xFFFFFFFF)
private val Ink = Color(0xFF40372D)
private val Muted = Color(0xFF82786C)
private const val BASE = "https://micakee.ir"
private val http = OkHttpClient()

private suspend fun api(path: String, method: String = "GET", body: String? = null, token: String = ""): Result<String> = withContext(Dispatchers.IO) {
    runCatching {
        val rb = body?.toRequestBody("application/json".toMediaType())
        val req = Request.Builder().url(BASE + path)
            .apply { if (token.isNotBlank()) addHeader("Authorization", "Bearer $token") }
            .method(method, rb).build()
        http.newCall(req).execute().use { res ->
            val text = res.body?.string().orEmpty()
            if (!res.isSuccessful) error(JSONObject(text.ifBlank { "{}" }).optString("error", "خطای سرور"))
            text
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { MiCakeeApp(this) } }
    }
}

@Composable private fun Logo(modifier: Modifier = Modifier) {
    Image(painterResource(R.drawable.micakee_logo), null, modifier.clip(RoundedCornerShape(24.dp)), contentScale = ContentScale.Crop)
}

@Composable private fun MiCakeeApp(ctx: Context) {
    val pref = ctx.getSharedPreferences("micakee", Context.MODE_PRIVATE)
    var token by remember { mutableStateOf(pref.getString("token", "").orEmpty()) }
    var screen by remember { mutableStateOf(if (token.isBlank()) "login" else "splash") }
    var mobile by remember { mutableStateOf(pref.getString("mobile", "").orEmpty()) }
    var otp by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var requestNonce by remember { mutableIntStateOf(0) }
    var verifyNonce by remember { mutableIntStateOf(0) }

    MaterialTheme(colorScheme = lightColorScheme(primary = Teal, secondary = Gold, background = Cream)) {
        when (screen) {
            "login" -> LoginScreen(mobile, { mobile = it }, busy, msg) { if (!Regex("09\\d{9}").matches(mobile)) { msg = "شماره موبایل ۱۱ رقمی معتبر وارد کن." } else { busy=true; msg="در حال ارسال کد..."; requestNonce++ } }
            "otp" -> OtpScreen(otp, { otp=it }, busy, msg, { screen="login"; otp="" }) { if (!Regex("\\d{6}").matches(otp)) msg="کد ۶ رقمی را وارد کن." else { busy=true; msg="در حال بررسی کد..."; verifyNonce++ } }
            "splash" -> SplashScreen { screen = "home" }
            "home" -> HomeScreen({screen="profile"},{screen="recipes"},{screen="calc"},{screen="price"},{screen="design"},{screen="assistant"},{screen="subscription"},{screen="stickers"},{screen="mold"})
            "subscription" -> SubscriptionScreen { screen="home" }
            "profile" -> ProfileScreen(token,{screen="home"}) { pref.edit().clear().apply(); token=""; mobile=""; screen="login" }
            "recipes" -> RecipesScreen(token){screen="home"}
            "calc" -> CalculatorScreen{screen="home"}
            "price" -> PriceScreen{screen="home"}
            "mold" -> MoldScreen { screen = "home" }
            "design" -> DesignScreen(token){screen="home"}
            "assistant" -> AssistantScreen(token){screen="home"}
            "stickers" -> StickerScreen { screen = "home" }
        }
        LaunchedEffect(requestNonce) { if(requestNonce==0) return@LaunchedEffect; val r=api("/api/auth/request-otp","POST",JSONObject().put("mobile",mobile).toString()); busy=false; r.onSuccess { msg="کد ارسال شد ✨"; screen="otp" }.onFailure { msg="⚠️ ${it.message}" } }
        LaunchedEffect(verifyNonce) { if(verifyNonce==0) return@LaunchedEffect; val r=api("/api/auth/verify-otp","POST",JSONObject().put("mobile",mobile).put("code",otp).toString()); busy=false; r.onSuccess { val t=JSONObject(it).optString("token"); if(t.isBlank()) msg="پاسخ ورود نامعتبر است." else { pref.edit().putString("token",t).putString("mobile",mobile).apply(); token=t; msg=""; screen="home" } }.onFailure { msg="⚠️ ${it.message}" } }
    }
}

@Composable private fun LoginScreen(m:String,onM:(String)->Unit,busy:Boolean,msg:String,onNext:()->Unit){
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(DeepTeal, Teal, Cream)))) {
        Column(Modifier.fillMaxSize().padding(22.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){
            Logo(Modifier.size(150.dp)); Spacer(Modifier.height(20.dp)); Text("می‌کیک",fontSize=34.sp,fontWeight=FontWeight.ExtraBold,color=White); Text("دستیار هوشمند قنادها",fontSize=18.sp,color=White); Spacer(Modifier.height(28.dp))
            Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(30.dp),colors=CardDefaults.cardColors(containerColor=White)){ Column(Modifier.padding(22.dp)){ Text("خوش اومدی قناد جان 👩🏻‍🍳",fontSize=21.sp,fontWeight=FontWeight.Bold,color=Ink); Text("برای ورود فقط شماره موبایلت رو وارد کن.",color=Muted); Spacer(Modifier.height(18.dp)); OutlinedTextField(m,onM,label={Text("شماره موبایل")},singleLine=true,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp)); Spacer(Modifier.height(12.dp)); Button(onClick=onNext,enabled=!busy,modifier=Modifier.fillMaxWidth().height(56.dp),shape=RoundedCornerShape(18.dp),colors=ButtonDefaults.buttonColors(containerColor=Teal)){Text(if(busy)"در حال ارسال..." else "دریافت کد ورود  ←",fontSize=17.sp,fontWeight=FontWeight.Bold)}; if(msg.isNotBlank()){Spacer(Modifier.height(10.dp));Text(msg,color=Teal)} } }
        }
    }
}

@Composable private fun OtpScreen(o:String,onO:(String)->Unit,busy:Boolean,msg:String,onBack:()->Unit,onVerify:()->Unit){
    Surface(Modifier.fillMaxSize(),color=Cream){Column(Modifier.fillMaxSize().padding(22.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Logo(Modifier.size(100.dp));Spacer(Modifier.height(18.dp));Text("تأیید ورود",fontSize=28.sp,fontWeight=FontWeight.ExtraBold,color=Ink);Text("کد ۶ رقمی پیامک را وارد کن",color=Muted);Spacer(Modifier.height(22.dp));OutlinedTextField(o,{if(it.length<=6)onO(it)},label={Text("کد تأیید")},singleLine=true,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp));Spacer(Modifier.height(12.dp));Button(onClick=onVerify,enabled=!busy,modifier=Modifier.fillMaxWidth().height(56.dp),shape=RoundedCornerShape(18.dp),colors=ButtonDefaults.buttonColors(containerColor=Teal)){Text(if(busy)"در حال بررسی..." else "تأیید و ورود",fontSize=17.sp,fontWeight=FontWeight.Bold)};TextButton(onClick=onBack){Text("ویرایش شماره",color=Teal)};if(msg.isNotBlank())Text(msg,color=Teal)}}
}

@Composable
private fun SplashScreen(done: () -> Unit) {
    LaunchedEffect(Unit) { delay(1200); done() }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(DeepTeal, Teal, Cream))), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Logo(Modifier.size(190.dp))
            Spacer(Modifier.height(18.dp))
            Text("mi.cakee", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = White)
            Text("دستیار هوشمند قنادها", fontSize = 17.sp, color = White.copy(alpha=.92f))
            Spacer(Modifier.height(28.dp))
            Text("هر ایده، یک کیک حرفه‌ای ✨", fontSize = 15.sp, color = Gold)
        }
    }
}

@Composable
private fun HomeScreen(
    account:()->Unit, recipes:()->Unit, calc:()->Unit, price:()->Unit,
    design:()->Unit, assistant:()->Unit, subscription:()->Unit,
    stickers:()->Unit, mold:()->Unit
) {
    Scaffold(
        containerColor = Cream,
        bottomBar = {
            Surface(color = DeepTeal, shadowElevation = 14.dp) {
                Row(
                    Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 8.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BottomButton("⌂", "خانه") { }
                    BottomButton("✦", "هوش مصنوعی") { design() }
                    BottomButton("▤", "دستورها") { recipes() }
                    BottomButton("♟", "حساب") { account() }
                }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().background(Cream)) {
            // Soft cake-photo backdrop, kept subtle so text remains readable.
            Image(
                painter = painterResource(R.drawable.mi_cake_hero_clean),
                contentDescription = null,
                modifier = Modifier.fillMaxWidth().height(520.dp).align(Alignment.TopCenter).alpha(0.16f),
                contentScale = ContentScale.Crop
            )
            Column(
                Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())
                    .padding(horizontal = 18.dp),
                verticalArrangement = Arrangement.spacedBy(15.dp)
            ) {
                Spacer(Modifier.height(8.dp))

                // Brand header: account status, centered identity, and app mark.
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(
                        Modifier.weight(1f).clickable { subscription() },
                        horizontalAlignment = Alignment.Start
                    ) {
                        Text("حساب من", fontSize = 12.sp, color = Muted)
                        Text("رایگان", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = DeepTeal)
                    }
                    Column(Modifier.weight(2f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("♕", fontSize = 28.sp, color = Gold)
                        Text("mi.cakee", fontSize = 29.sp, fontWeight = FontWeight.ExtraBold, color = DeepTeal)
                        Text("دستیار هوشمند قنادها", fontSize = 12.sp, color = Muted)
                    }
                    Box(Modifier.weight(1f), contentAlignment = Alignment.CenterEnd) {
                        Logo(Modifier.size(72.dp))
                    }
                }

                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End) {
                    Text("سلام قناد جان 👋", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = DeepTeal)
                    Text("امروز دوست داری چه چیزی بسازی؟", fontSize = 16.sp, color = Ink)
                }

                // Main cake-design feature card.
                Card(
                    Modifier.fillMaxWidth().clickable { design() },
                    shape = RoundedCornerShape(30.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF8E9)),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, Gold),
                    elevation = CardDefaults.cardElevation(5.dp)
                ) {
                    Column(Modifier.fillMaxWidth()) {
                        Image(
                            painter = painterResource(R.drawable.mi_cake_hero_clean),
                            contentDescription = "کیک می‌کیک",
                            modifier = Modifier.fillMaxWidth().height(178.dp),
                            contentScale = ContentScale.Crop
                        )
                        Column(Modifier.fillMaxWidth().padding(horizontal = 19.dp, vertical = 17.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("✦", color = Gold, fontSize = 27.sp)
                                Spacer(Modifier.width(9.dp))
                                Text("طراحی کیک با هوش مصنوعی", fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, color = DeepTeal)
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "ایده‌ات را بنویس؛ می‌کیک برایت سبک، رنگ و جزئیات یک طرح حرفه‌ای پیشنهاد می‌دهد.",
                                color = Ink, fontSize = 14.sp, lineHeight = 22.sp
                            )
                            Spacer(Modifier.height(13.dp))
                            Button(
                                onClick = design,
                                shape = RoundedCornerShape(22.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = DeepTeal),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Gold)
                            ) { Text("←  شروع طراحی", color = GoldSoft, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
                        }
                    }
                }

                Card(
                    Modifier.fillMaxWidth().clickable { stickers() },
                    shape = RoundedCornerShape(27.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF7E9)),
                    border = androidx.compose.foundation.BorderStroke(1.2.dp, Gold),
                    elevation = CardDefaults.cardElevation(3.dp)
                ) {
                    Row(Modifier.fillMaxWidth().padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                        Image(painterResource(R.drawable.mi_cake_slice), contentDescription = "برش کیک", modifier = Modifier.size(76.dp).clip(RoundedCornerShape(16.dp)), contentScale = ContentScale.Crop)
                        Spacer(Modifier.width(13.dp))
                        Column(Modifier.weight(1f)) {
                            Text("ساخت استیکر برای کانال", fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, color = DeepTeal)
                            Text("ثبت متن و انتخاب سبک؛ تولید هوشمند بعداً فعال می‌شود.", fontSize = 13.sp, color = Ink, lineHeight = 19.sp)
                        }
                        Text("←", color = DeepTeal, fontSize = 23.sp)
                    }
                }

                Card(
                    Modifier.fillMaxWidth().clickable { subscription() },
                    shape = RoundedCornerShape(27.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF7E9)),
                    border = androidx.compose.foundation.BorderStroke(1.2.dp, Gold),
                    elevation = CardDefaults.cardElevation(3.dp)
                ) {
                    Row(Modifier.fillMaxWidth().padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                        Image(painterResource(R.drawable.mi_cake_small), contentDescription = "کیک تزئین‌شده", modifier = Modifier.size(76.dp).clip(RoundedCornerShape(16.dp)), contentScale = ContentScale.Crop)
                        Spacer(Modifier.width(13.dp))
                        Column(Modifier.weight(1f)) {
                            Text("ارتقا به اشتراک حرفه‌ای", color = DeepTeal, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                            Text("استفاده بیشتر از امکانات هوشمند", color = Ink, fontSize = 13.sp)
                        }
                        Text("مشاهده", color = DeepTeal, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }

                Card(
                    Modifier.fillMaxWidth().clickable { calc() },
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFEAF5EF)),
                    border = androidx.compose.foundation.BorderStroke(1.2.dp, Gold),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("⚖️", fontSize = 30.sp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("تغییر مقدار مواد", color = DeepTeal, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                            Text("محاسبه مواد بر اساس تعداد تخم‌مرغ؛ نصف یا دوبرابر", color = Ink, fontSize = 12.sp)
                        }
                        Text("←", color = DeepTeal, fontSize = 22.sp)
                    }
                }

                Text("دسترسی سریع", fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, color = DeepTeal)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    QuickAction(Modifier.weight(1f), "☆", "علاقه‌مندی‌ها") { recipes() }
                    QuickAction(Modifier.weight(1f), "▤", "دستورها") { recipes() }
                    QuickAction(Modifier.weight(1f), "💰", "قیمت‌ها") { price() }
                    QuickAction(Modifier.weight(1f), "📐", "قالب‌ها") { mold() }
                }

                Card(
                    Modifier.fillMaxWidth().clickable { assistant() },
                    shape = RoundedCornerShape(25.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF7E9)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Gold)
                ) {
                    Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("🎙", fontSize = 34.sp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("دستیار صوتی می‌کیک", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = DeepTeal)
                            Text("سؤال یا درخواستت را با صدای خودت بگو", fontSize = 12.sp, color = Muted)
                        }
                        Text("←", fontSize = 23.sp, color = DeepTeal)
                    }
                }
                Spacer(Modifier.height(18.dp))
            }
        }
    }
}

@Composable
private fun QuickAction(modifier: Modifier = Modifier, icon:String, title:String, onClick:()->Unit) {
    Card(
        modifier.height(112.dp).clickable { onClick() },
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.fillMaxSize().padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceBetween) {
            Box(Modifier.size(42.dp).clip(CircleShape).background(Cream), contentAlignment = Alignment.Center) { Text(icon, fontSize = 23.sp) }
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Ink)
        }
    }
}

@Composable
private fun RecipePreview(icon:String, title:String, subtitle:String) {
    Card(
        Modifier.width(190.dp).height(128.dp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = White)
    ) {
        Row(Modifier.fillMaxSize().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(56.dp).clip(RoundedCornerShape(18.dp)).background(Cream), contentAlignment = Alignment.Center) { Text(icon, fontSize = 31.sp) }
            Spacer(Modifier.width(11.dp))
            Column {
                Text(title, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
                Spacer(Modifier.height(5.dp))
                Text(subtitle, fontSize = 11.sp, color = Muted, lineHeight = 16.sp)
            }
        }
    }
}

@Composable
private fun SubscriptionScreen(back:()->Unit){
    SimplePage("اشتراک می‌کیک",back){
        Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(28.dp),colors=CardDefaults.cardColors(containerColor=DeepTeal)){
            Column(Modifier.padding(22.dp)){Text("👑 اشتراک حرفه‌ای",fontSize=25.sp,fontWeight=FontWeight.ExtraBold,color=Gold);Spacer(Modifier.height(8.dp));Text("برای استفاده بیشتر از امکانات هوشمند می‌کیک",color=White);Spacer(Modifier.height(18.dp));
                listOf("طراحی کیک با هوش مصنوعی بیشتر","دستیار هوشمند بیشتر","جست‌وجوی دستورهای بیشتر","ذخیره دستورهای بیشتر").forEach{Text("✓  $it",color=White,fontSize=15.sp,modifier=Modifier.padding(vertical=5.dp))}
            }
        }
        Spacer(Modifier.height(14.dp))
        Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=White)){Column(Modifier.padding(20.dp)){Text("پلن فعلی",fontWeight=FontWeight.Bold,fontSize=18.sp,color=Ink);Text("رایگان",fontSize=25.sp,fontWeight=FontWeight.ExtraBold,color=Teal);Text("امکانات پایه برای شروع رایگان هستند.",color=Muted);Spacer(Modifier.height(14.dp));Button(onClick={},modifier=Modifier.fillMaxWidth().height(52.dp),shape=RoundedCornerShape(16.dp),colors=ButtonDefaults.buttonColors(containerColor=Teal)){Text("خرید اشتراک حرفه‌ای")}}}
    }
}

@Composable private fun BottomButton(icon:String,label:String,onClick:()->Unit){
    Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.clickable{onClick()}.padding(horizontal=12.dp, vertical=2.dp)){Text(icon,fontSize=22.sp,color=Gold);Text(label,fontSize=11.sp,fontWeight=FontWeight.SemiBold,color=GoldSoft)}
}

@Composable private fun ToolCard(icon:String,title:String,onClick:()->Unit){Card(Modifier.height(128.dp).clickable{onClick()},shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=White)){Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.SpaceBetween){Box(Modifier.size(48.dp).clip(CircleShape).background(Cream),contentAlignment=Alignment.Center){Text(icon,fontSize=25.sp)};Text(title,fontSize=15.sp,fontWeight=FontWeight.Bold,color=Ink)}}}


@Composable private fun CalcRow(label:String,value:Int,unit:String){
    Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=White)){
        Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically){
            Text(label,fontWeight=FontWeight.Bold,color=Ink,modifier=Modifier.weight(1f))
            Text("$value $unit",fontWeight=FontWeight.Bold,color=Teal)
        }
    }
    Spacer(Modifier.height(8.dp))
}

@Composable private fun ProfileScreen(token:String,back:()->Unit,logout:()->Unit){var text by remember{mutableStateOf("در حال دریافت اطلاعات حساب...")};LaunchedEffect(token){api("/api/me",token=token).onSuccess{val u=JSONObject(it).optJSONObject("user");text="شماره موبایل: ${u?.optString("mobile","")}\nنوع حساب: ${u?.optString("plan","رایگان")}"}.onFailure{text="⚠️ ${it.message}"}};SimplePage("حساب کاربری",back){Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(26.dp),colors=CardDefaults.cardColors(containerColor=White)){Column(Modifier.padding(20.dp)){Text("حساب من",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Ink);Spacer(Modifier.height(10.dp));Text(text,color=Muted)}};Spacer(Modifier.height(16.dp));Button(logout,Modifier.fillMaxWidth().height(52.dp),shape=RoundedCornerShape(16.dp),colors=ButtonDefaults.buttonColors(containerColor=Teal)){Text("خروج از حساب")}}
}

@Composable private fun RecipesScreen(token:String,back:()->Unit){
    var list by remember{mutableStateOf(listOf<Pair<String,String>>())}
    var msg by remember{mutableStateOf("در حال دریافت دستورها...")}
    LaunchedEffect(Unit){
        api("/api/recipes",token=token).onSuccess{a->
            val j=JSONArray(a)
            list=(0 until j.length()).map{val x=j.getJSONObject(it);x.optString("name") to x.optString("category")}
            msg=if(list.isEmpty())"بانک دستورها فعلاً خالی است." else ""
        }.onFailure{msg="⚠️ ${it.message}"}
    }
    SimplePage("بانک دستورهای می‌کیک",back){
        if(msg.isNotBlank())Text(msg,color=Muted)
        list.forEach{x->
            Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=White)){
                Column(Modifier.padding(17.dp)){
                    Text(x.first,fontWeight=FontWeight.Bold,fontSize=17.sp,color=Ink)
                    Text(x.second,color=Teal,fontSize=13.sp)
                }
            }
            Spacer(Modifier.height(10.dp))
        }
    }
}

private data class CustomIngredient(
    val name: String,
    val amount: String,
    val unit: String
)

@Composable
private fun CalculatorScreen(back: () -> Unit) {
    var multiplier by remember { mutableStateOf(1.0) }
    var customName by remember { mutableStateOf("") }
    var customAmount by remember { mutableStateOf("") }
    var customUnit by remember { mutableStateOf("گرم") }
    var customIngredients by remember { mutableStateOf(listOf<CustomIngredient>()) }
    var addMessage by remember { mutableStateOf("") }
    fun normalizeNumber(input: String): String = input
        .replace('۰', '0').replace('۱', '1').replace('۲', '2').replace('۳', '3')
        .replace('۴', '4').replace('۵', '5').replace('۶', '6').replace('۷', '7')
        .replace('۸', '8').replace('۹', '9')
        .replace('٠', '0').replace('١', '1').replace('٢', '2').replace('٣', '3')
        .replace('٤', '4').replace('٥', '5').replace('٦', '6').replace('٧', '7')
        .replace('٨', '8').replace('٩', '9')

    fun scaled(raw: String): String {
        val value = (normalizeNumber(raw).replace(',', '.').toDoubleOrNull() ?: 0.0) * multiplier
        return if (value % 1.0 == 0.0) value.toLong().toString()
        else String.format(java.util.Locale.US, "%.3f", value).trimEnd('0').trimEnd('.')
    }

    SimplePage("محاسبه مواد اولیه", back) {
        Text("مواد دستور خودت را وارد کن؛ نام، مقدار و واحد هر ماده دلخواه است.", color = Muted, fontSize = 14.sp)
        Text("مقدار مواد را تغییر بده", color = DeepTeal, fontWeight = FontWeight.Bold)
        val scales = listOf(1.0/4.0 to "یک‌چهارم", 1.0/3.0 to "یک‌سوم", 0.5 to "نصف", 1.0 to "اصلی", 2.0 to "۲ برابر", 3.0 to "۳ برابر", 4.0 to "۴ برابر")
        scales.chunked(4).forEach { chunk ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                chunk.forEach { (factor, label) ->
                    FilterChip(
                        selected = multiplier == factor,
                        onClick = { multiplier = factor },
                        label = { Text(label, fontSize = 11.sp) },
                        modifier = Modifier.weight(1f)
                    )
                }
                repeat(4 - chunk.size) { Spacer(Modifier.weight(1f)) }
            }
        }
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF7E8))) {
            Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("مواد دستور", color = DeepTeal, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
                if (customIngredients.isEmpty()) {
                    Text("هنوز ماده‌ای اضافه نکرده‌ای. از قسمت پایین مواد را وارد کن.", color = Muted)
                } else {
                    customIngredients.forEachIndexed { index, item ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(item.name, color = Ink, fontWeight = FontWeight.Bold)
                                Text("${scaled(item.amount)} ${item.unit}", color = Teal)
                            }
                            TextButton(onClick = { customIngredients = customIngredients.toMutableList().also { it.removeAt(index) } }) {
                                Text("حذف", color = Color(0xFFB44B42))
                            }
                        }
                        if (index != customIngredients.lastIndex) Divider(color = Gold.copy(alpha = 0.35f))
                    }
                }
            }
        }
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = White)) {
            Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("افزودن ماده اولیه", color = DeepTeal, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
                OutlinedTextField(customName, { customName = it }, label = { Text("نام ماده؛ مثلاً آرد") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(customAmount, { customAmount = it.filter { c -> c.isDigit() || c == '.' || c == ',' } }, label = { Text("مقدار") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(customUnit, { customUnit = it }, label = { Text("واحد؛ گرم، عدد...") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                Button(
                    onClick = {
                        val normalizedAmount = normalizeNumber(customAmount).replace(',', '.')
                        val a = normalizedAmount.toDoubleOrNull()
                        when {
                            customName.isBlank() -> addMessage = "نام ماده را وارد کن."
                            customUnit.isBlank() -> addMessage = "واحد ماده را وارد کن."
                            a == null || a <= 0.0 -> addMessage = "مقدار معتبر و بزرگ‌تر از صفر وارد کن."
                            else -> {
                                customIngredients = customIngredients + CustomIngredient(customName.trim(), normalizedAmount, customUnit.trim())
                                customName = ""; customAmount = ""; addMessage = "ماده با موفقیت اضافه شد."
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = DeepTeal)
                ) { Text("افزودن به مواد") }
                if (addMessage.isNotBlank()) Text(addMessage, color = Teal, fontSize = 12.sp)
                Text("می‌توانی هر تعداد ماده با واحدهای دلخواه اضافه کنی.", color = Muted, fontSize = 12.sp)
            }
        }
        Text("ضریب انتخاب‌شده روی تمام مواد اعمال می‌شود. برای مقدار دلخواه، نزدیک‌ترین ضریب را انتخاب کن؛ در صورت نیاز مقدار اولیه را متناسب وارد کن.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun PriceScreen(back: () -> Unit) {
    data class MaterialRow(val name: String, val packAmount: String, val packPrice: String, val usedAmount: String, val unit: String)
    var rows by remember {
        mutableStateOf(listOf(
            MaterialRow("آرد", "1000", "60000", "100", "گرم"),
            MaterialRow("شکر", "1000", "80000", "100", "گرم"),
            MaterialRow("تخم‌مرغ", "4", "80000", "2", "عدد")
        ))
    }
    var customName by remember { mutableStateOf("") }
    var margin by remember { mutableStateOf("30") }
    var extraCost by remember { mutableStateOf("0") }
    val materialCost = rows.sumOf { row ->
        val pack = row.packAmount.toDoubleOrNull() ?: 0.0
        val price = row.packPrice.toDoubleOrNull() ?: 0.0
        val used = row.usedAmount.toDoubleOrNull() ?: 0.0
        if (pack > 0 && price >= 0 && used >= 0) price * used / pack else 0.0
    }
    val extras = extraCost.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
    val total = materialCost + extras
    val percent = margin.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
    val sale = total * (1 + percent / 100.0)
    SimplePage("قیمت‌گذاری و سود", back) {
        Text("برای هر ماده، مقدار خرید، قیمت کل بسته و مقدار مصرف‌شده را وارد کن.", color = Muted, fontSize = 13.sp)
        rows.forEachIndexed { index, row ->
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = White)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(row.name, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Ink)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(row.packAmount, { value -> rows = rows.toMutableList().also { it[index] = row.copy(packAmount = value.filter { c -> c.isDigit() || c == '.' }) } }, label = { Text("مقدار بسته") }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(row.packPrice, { value -> rows = rows.toMutableList().also { it[index] = row.copy(packPrice = value.filter { c -> c.isDigit() || c == '.' }) } }, label = { Text("قیمت بسته (تومان)") }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                    OutlinedTextField(row.usedAmount, { value -> rows = rows.toMutableList().also { it[index] = row.copy(usedAmount = value.filter { c -> c.isDigit() || c == '.' }) } }, label = { Text("مقدار مصرف (${row.unit})") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    val pack = row.packAmount.toDoubleOrNull() ?: 0.0
                    val price = row.packPrice.toDoubleOrNull() ?: 0.0
                    val used = row.usedAmount.toDoubleOrNull() ?: 0.0
                    Text("هزینه این ماده: ${if (pack > 0) (price * used / pack).toLong() else 0} تومان", color = Teal, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(customName, { customName = it }, label = { Text("نام ماده جدید") }, modifier = Modifier.weight(1f), singleLine = true)
            Button(onClick = { if (customName.isNotBlank()) { rows = rows + MaterialRow(customName.trim(), "1000", "0", "0", "گرم"); customName = "" } }, colors = ButtonDefaults.buttonColors(containerColor = Teal)) { Text("افزودن") }
        }
        OutlinedTextField(extraCost, { extraCost = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("هزینه‌های دیگر (تومان؛ جعبه، برق و...) ") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(margin, { margin = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("درصد سود روی هزینه") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFF8E2EB))) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("جمع هزینه مواد: ${materialCost.toLong()} تومان", color = Ink)
                Text("هزینه کل با هزینه‌های دیگر: ${total.toLong()} تومان", color = Ink, fontWeight = FontWeight.Bold)
                Text("قیمت پیشنهادی با ${percent.toLong()}٪ سود: ${sale.toLong()} تومان", fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, color = DeepTeal)
            }
        }
        Text("نکته: واحد مقدار خرید و مصرف باید یکی باشد؛ مثلاً هر دو گرم یا هر دو عدد.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun DesignScreen(token: String, back: () -> Unit) {
    var prompt by remember { mutableStateOf("") }
    var out by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var nonce by remember { mutableIntStateOf(0) }
    LaunchedEffect(nonce) {
        if (nonce == 0) return@LaunchedEffect
        api("/api/design", "POST", JSONObject().put("prompt", prompt).toString(), token)
            .onSuccess {
                out = JSONObject(it).optString("answer", "طرحی دریافت نشد.")
                busy = false
            }
            .onFailure {
                out = "⚠️ ${it.message}"
                busy = false
            }
    }
    SimplePage("طراحی کیک با هوش مصنوعی", back) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Teal)
        ) {
            Column(Modifier.padding(20.dp)) {
                Text("کیک رویایی‌ات را توصیف کن ✨", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = White)
                Spacer(Modifier.height(6.dp))
                Text("رنگ، مناسبت، تعداد طبقات و سبک تزیین را بنویس.", color = White.copy(alpha = .85f))
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = prompt,
                    onValueChange = { prompt = it },
                    label = { Text("مثلاً کیک تولد دخترانه فیروزه‌ای و طلایی") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 4,
                    shape = RoundedCornerShape(18.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        unfocusedContainerColor = White,
                        focusedContainerColor = White
                    )
                )
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = { busy = true; nonce++ },
                    enabled = !busy && prompt.isNotBlank(),
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold)
                ) {
                    Text(if (busy) "در حال ساخت..." else "ساخت طرح پیشنهادی", color = Ink, fontWeight = FontWeight.Bold)
                }
            }
        }
        if (out.isNotBlank()) {
            Spacer(Modifier.height(14.dp))
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = White)
            ) {
                Text(out, Modifier.padding(18.dp), color = Ink, fontSize = 15.sp)
            }
        }
    }
}

@Composable
private fun AssistantScreen(token: String, back: () -> Unit) {
    var q by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("سلام قناد جان 👑\nسؤالت را درباره شیرینی و قنادی بپرس.") }
    var busy by remember { mutableStateOf(false) }
    var nonce by remember { mutableIntStateOf(0) }
    LaunchedEffect(nonce) {
        if (nonce == 0) return@LaunchedEffect
        api("/api/ai/ask", "POST", JSONObject().put("text", q).toString(), token)
            .onSuccess {
                answer = JSONObject(it).optString("answer", "پاسخی دریافت نشد.")
                busy = false
            }
            .onFailure {
                answer = "⚠️ ${it.message}"
                busy = false
            }
    }
    SimplePage("دستیار هوشمند قنادها", back) {
        Card(
            shape = RoundedCornerShape(26.dp),
            colors = CardDefaults.cardColors(containerColor = White)
        ) {
            Text(answer, Modifier.padding(20.dp), color = Ink, fontSize = 17.sp)
        }
        Spacer(Modifier.weight(1f))
        OutlinedTextField(
            value = q,
            onValueChange = { q = it },
            label = { Text("سؤالت را بنویس...") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 2,
            shape = RoundedCornerShape(18.dp)
        )
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = { busy = true; nonce++ },
            enabled = !busy && q.isNotBlank(),
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Teal)
        ) {
            Text(if (busy) "در حال پاسخ..." else "ارسال سؤال")
        }
    }
}

@Composable
private fun MoldScreen(back: () -> Unit) {
    var shape by remember { mutableStateOf("گرد") }
    var base by remember { mutableStateOf("20") }
    var length by remember { mutableStateOf("20") }
    var width by remember { mutableStateOf("20") }
    // Default reference heights; users can change the height and the quantities scale proportionally.
    var heightText by remember { mutableStateOf(if (shape == "گرد") "8" else "5") }
    val height = heightText.toDoubleOrNull()?.coerceAtLeast(0.1) ?: if (shape == "گرد") 8.0 else 5.0
    val referenceHeight = if (shape == "گرد") 8.0 else 5.0
    val heightScale = height / referenceHeight
    val d = base.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
    val l = length.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
    val w = width.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
    val calculatedEggs = when (shape) {
        "گرد" -> {
            // Published reference points: 15 cm = 3, 18 cm = 4, 20 cm = 5, 23 cm = 6 eggs.
            val points = listOf(15.0 to 3.0, 18.0 to 4.0, 20.0 to 5.0, 23.0 to 6.0)
            val estimate = when {
                d <= points.first().first -> d / points.first().first * points.first().second
                d >= points.last().first -> points.last().second * d / points.last().first
                else -> {
                    val pair = points.zipWithNext().first { d >= it.first.first && d <= it.second.first }
                    val (x1, y1) = pair.first
                    val (x2, y2) = pair.second
                    y1 + (d - x1) * (y2 - y1) / (x2 - x1)
                }
            }
            kotlin.math.round(estimate * heightScale).toInt().coerceAtLeast(1)
        }
        "مربع" -> kotlin.math.round(5.0 * l * l / (20.0 * 20.0) * heightScale).toInt().coerceAtLeast(1)
        else -> kotlin.math.round(6.0 * l * w / (30.0 * 20.0) * heightScale).toInt().coerceAtLeast(1)
    }
    SimplePage("محاسبه قالب کیک", back) {
        Text("ابعاد و ارتفاع قالب را وارد کن؛ تعداد تخم‌مرغ و مقدار مواد به‌صورت خودکار محاسبه می‌شود.", color = Muted)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("گرد", "مربع", "مستطیل").forEach { option ->
                FilterChip(selected = shape == option, onClick = { shape = option }, label = { Text(option) })
            }
        }
        if (shape == "گرد") {
            OutlinedTextField(base, { base = it.filter { c -> c.isDigit() || c == '.' || c == '٫' }.replace('٫', '.') }, label = { Text("قطر قالب استوانه‌ای (سانتی‌متر)") }, modifier = Modifier.fillMaxWidth())
        } else {
            OutlinedTextField(length, { length = it.filter { c -> c.isDigit() || c == '.' || c == '٫' }.replace('٫', '.') }, label = { Text(if (shape == "مربع") "ضلع قالب مربع (سانتی‌متر)" else "طول قالب مستطیل (سانتی‌متر)") }, modifier = Modifier.fillMaxWidth())
            if (shape == "مستطیل") OutlinedTextField(width, { width = it.filter { c -> c.isDigit() || c == '.' || c == '٫' }.replace('٫', '.') }, label = { Text("عرض قالب مستطیل (سانتی‌متر)") }, modifier = Modifier.fillMaxWidth())
        }
        OutlinedTextField(
            value = heightText,
            onValueChange = { heightText = it.filter { c -> c.isDigit() || c == '.' || c == '٫' }.replace('٫', '.') },
            label = { Text("ارتفاع قالب (سانتی‌متر)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFF8E2EB))) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("تخم‌مرغ پیشنهادی: $calculatedEggs عدد", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = DeepTeal)
                Text("آرد: ${calculatedEggs * 30} گرم  •  شکر: ${calculatedEggs * 30} گرم", color = Ink)
                Text("آب: ${calculatedEggs * 10} گرم  •  روغن: ${calculatedEggs * 10} گرم", color = Ink)
                Text("بیکینگ‌پودر: حدود ${calculatedEggs * 2} گرم؛ وانیل: نوک قاشق به ازای هر تخم‌مرغ", color = Ink)
            }
        }
        Text("مبنای تخم‌مرغ: گرد ۱۵ سانت ۳ عدد، ۱۸ سانت ۴ عدد، ۲۰ سانت ۵ عدد، ۲۳ سانت ۶ عدد؛ مربع ۲۰ سانت ۵ عدد؛ مستطیل ۲۰×۳۰ سانت ۶ عدد و ۲۵×۳۰ سانت حدود ۷ تا ۸ عدد. مقدار مواد دیگر طبق دستور هر تخم‌مرغ برنامه است.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun StickerScreen(onBack: () -> Unit) {
    var channelName by remember { mutableStateOf("") }
    var stickerText by remember { mutableStateOf("") }
    var stickerStyle by remember { mutableStateOf("فانتزی") }
    SimplePage("ساخت استیکر", onBack) {
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFF8E2EB))) {
            Column(Modifier.padding(20.dp)) {
                Text("🎀 استیکر اختصاصی کانالت", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = DeepTeal)
                Text("فعلاً پیش‌نمایش رایگان؛ تولید خودکار در آینده اضافه می‌شود.", color = Ink)
            }
        }
        OutlinedTextField(channelName, { channelName = it }, label = { Text("نام کانال یا پیج") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(stickerText, { stickerText = it }, label = { Text("متن استیکر") }, placeholder = { Text("مثلاً: سفارش‌گیری باز است") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
        Text("سبک استیکر", color = Ink, fontWeight = FontWeight.Bold)
        listOf("فانتزی", "مینیمال", "کیک و شیرینی", "بامزه").forEach { option ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(if (stickerStyle == option) Color(0xFFF8E2EB) else White).clickable { stickerStyle = option }.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = stickerStyle == option, onClick = { stickerStyle = option })
                Text(option, color = Ink)
            }
        }
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = White)) {
            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("✨ 🎂 ✨", fontSize = 30.sp)
                Text(stickerText.ifBlank { "پیش‌نمایش استیکر" }, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, color = DeepTeal)
                if (channelName.isNotBlank()) Text("@$channelName", color = Muted)
                Text("سبک: $stickerStyle", color = Muted)
            }
        }
        Text("ساخت تصویر و ذخیره‌سازی هنوز فعال نیست و به سرویس پولی متصل نشده است.", color = Muted, fontSize = 12.sp)
    }
}

@Composable private fun SimplePage(title:String,back:()->Unit,content:@Composable ColumnScope.()->Unit){
    Surface(Modifier.fillMaxSize(),color=Cream){
        Column(Modifier.fillMaxSize().padding(horizontal=18.dp,vertical=16.dp)){
            Row(verticalAlignment=Alignment.CenterVertically){
                Text("‹",fontSize=34.sp,color=Teal,modifier=Modifier.clickable{back()})
                Spacer(Modifier.width(5.dp))
                Text(title,fontSize=23.sp,fontWeight=FontWeight.ExtraBold,color=DeepTeal)
            }
            Spacer(Modifier.height(9.dp))
            Box(Modifier.fillMaxWidth().height(2.dp).clip(CircleShape).background(Gold))
            Spacer(Modifier.height(12.dp))
            Image(
                painter = painterResource(R.drawable.mi_cake_hero_clean),
                contentDescription = "کیک می‌کیک",
                modifier = Modifier.fillMaxWidth().height(112.dp).clip(RoundedCornerShape(22.dp)),
                contentScale = ContentScale.Crop
            )
            Spacer(Modifier.height(14.dp))
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                content=content
            )
        }
    }
}
